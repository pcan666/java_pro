package com.itheima._10内部类_匿名内部类_重点;

public class Dog {
    public static void go(){
        System.out.println("🐕跑的贼溜~~~");
    }
}
