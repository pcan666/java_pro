package com.itheima._11包和权限修饰符;

public class Student {
    public static void inAddr(){
        System.out.println("我们在吉山区学习~~~");
    }
}
